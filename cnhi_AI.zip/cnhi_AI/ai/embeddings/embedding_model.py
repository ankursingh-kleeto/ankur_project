from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings

# Load PDF
loader = PyPDFLoader("requirements_docs/Login Requirement.pdf")
documents = loader.load()

# Split into chunks
splitter = RecursiveCharacterTextSplitter(
    chunk_size=100,
    chunk_overlap=20
)

chunks = splitter.split_documents(documents)

print(f"Chunks : {len(chunks)}")

# Load embedding model
embedding = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-MiniLM-L6-v2"
)

# Convert first chunk into vector
vector = embedding.embed_query(chunks[0].page_content)

print("\nEmbedding Length :", len(vector))
print("\nFirst 10 Values :")
print(vector[:10])