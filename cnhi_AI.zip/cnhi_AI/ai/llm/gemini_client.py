from google import genai

client = genai.Client(api_key="your api key")



def ask_gemini(prompt):
    response = client.models.generate_content(
        model="gemini-flash-latest",
        contents=prompt,
    )
    return response.text



