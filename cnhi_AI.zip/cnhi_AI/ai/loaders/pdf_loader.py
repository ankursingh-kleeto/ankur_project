import os
from langchain_community.document_loaders import PyPDFLoader

pdf_path = "requirements_docs/Login Requirement.pdf"

if not os.path.exists(pdf_path):
    raise FileNotFoundError(f"PDF not found: {pdf_path}")

if os.path.getsize(pdf_path) == 0:
    raise ValueError(f"PDF is empty: {pdf_path}")

loader = PyPDFLoader(pdf_path)
documents = loader.load()

print(f"Total Pages: {len(documents)}")

for i, page in enumerate(documents):
    print("=" * 50)
    print(f"Page {i + 1}")
    print("=" * 50)
    print(page.page_content)