import subprocess
import sys

def execute_action(action):

    if action == "LOGIN":

        print("Running Login Automation...")

        subprocess.run([
            sys.executable,
            "-m",
            "pytest",
            "tests/test_negative_scenarios.py",
            "-k",
            "login"
        ])

    elif action == "UPLOAD_DOCUMENT":

        print("Running Document Upload Automation...")

        subprocess.run([
            sys.executable,
            "-m",
            "pytest",
            "tests/test_negative_scenarios.py",
            "-k",
            "document"
        ])

    elif action == "FILL_FORM":

        print("Running Form Automation...")

        subprocess.run([
            sys.executable,
            "-m",
            "pytest",
            "tests/test_negative_scenarios.py",
            "-k",
            "form"
        ])

    else:

        print("AI could not understand the requirement.")