from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_chroma import Chroma

# -----------------------------
# Load PDF
# -----------------------------
loader = PyPDFLoader("requirements_docs/Login Requirement.pdf")
documents = loader.load()

# -----------------------------
# Split PDF
# -----------------------------
splitter = RecursiveCharacterTextSplitter(
    chunk_size=100,
    chunk_overlap=20
)

chunks = splitter.split_documents(documents)

print("Chunks :", len(chunks))

# -----------------------------
# Embedding Model
# -----------------------------
embedding = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-MiniLM-L6-v2"
)

# -----------------------------
# Store in ChromaDB
# -----------------------------
db = Chroma.from_documents(
    documents=chunks,
    embedding=embedding,
    persist_directory="./chroma_db"
)

print("Database Created Successfully")