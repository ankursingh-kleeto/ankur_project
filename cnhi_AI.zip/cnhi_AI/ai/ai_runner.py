from ai.action_parser import parse_action
from ai.ai_executor import execute_action


def run_ai_automation(requirement):

    print("=" * 60)
    print("Requirement :", requirement)
    print("=" * 60)

    action = parse_action(requirement)

    print("\nAI Decision")
    print(action)

    execute_action(action)