from langchain_chroma import Chroma
from langchain_huggingface import HuggingFaceEmbeddings

embedding = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-MiniLM-L6-v2"
)

db = Chroma(
    persist_directory="./chroma_db",
    embedding_function=embedding
)

query = input("Ask Requirement : ")

docs = db.similarity_search(query, k=2)

print("\nTop Results\n")

for i, doc in enumerate(docs):
    print("="*50)
    print(f"Result {i+1}")
    print("="*50)
    print(doc.page_content)