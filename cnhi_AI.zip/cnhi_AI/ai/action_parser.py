def parse_action(requirement):

    req = requirement.lower()

    # LOGIN
    if any(word in req for word in [
        "login",
        "sign in",
        "signin",
        "log in"
    ]):
        return "LOGIN"

    # DOCUMENT UPLOAD
    elif any(word in req for word in [
        "upload",
        "document",
        "pan",
        "aadhaar",
        "aadhar",
        "passport",
        "driving licence",
        "license",
        "resume",
        "photo"
    ]):
        return "UPLOAD_DOCUMENT"

    # FORM
    elif any(word in req for word in [
        "form",
        "fill",
        "candidate details",
        "personal details",
        "address",
        "education"
    ]):
        return "FILL_FORM"

    else:
        return "UNKNOWN"