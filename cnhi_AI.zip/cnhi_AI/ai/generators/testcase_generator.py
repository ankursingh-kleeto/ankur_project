from langchain_chroma import Chroma
from langchain_huggingface import HuggingFaceEmbeddings

from ai.llm.gemini_client import ask_gemini

embedding = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-MiniLM-L6-v2"
)

db = Chroma(
    persist_directory="./chroma_db",
    embedding_function=embedding
)

query = input("Enter Requirement : ")

docs = db.similarity_search(query, k=2)

context = ""

for doc in docs:
    context += doc.page_content + "\n"

prompt = f"""
You are a Senior QA Engineer.

Requirement:

{context}

Generate detailed Manual Test Cases.
"""

answer = ask_gemini(prompt)

print("\n")
print(answer)