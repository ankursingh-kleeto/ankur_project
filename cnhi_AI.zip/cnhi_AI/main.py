from ai.ai_runner import run_ai_automation

if __name__ == "__main__":

    requirement = input("\nEnter Requirement : ")

    run_ai_automation(requirement)