import os
from datetime import datetime
from openpyxl import Workbook, load_workbook
from utils.report_generator import AutomationReport

EXCEL_FILE = "execution_results.xlsx"

class TestReporter:

    @staticmethod
    def init_excel():
        """Excel initialize with proper Activity & User Input Tracking"""
        if not os.path.exists(EXCEL_FILE):
            wb = Workbook()
            
            # Sheet 1: Negative Tests (Failed Attempts / Security Blocks)
            ws_neg = wb.active
            ws_neg.title = "Negative Tests"
            ws_neg.append(["Timestamp", "Activity / Stage Name", "Login Id / Password / Input Entered", "Attempt Status", "UI Red Error Captured"])

            # Sheet 2: Positive Tests (Valid Workflow Executions)
            ws_pos = wb.create_sheet(title="Positive Tests")
            ws_pos.append(["Timestamp", "Activity / Stage Name", "Login Id / Password / File Attached", "Attempt Status", "Execution Result / Message"])

            try:
                wb.save(EXCEL_FILE)
            except PermissionError:
                wb.save("execution_results_latest.xlsx")

    @staticmethod
    def log_to_excel(sheet_type, activity_name, input_data, status, error_or_result):
        """Logs every user attempt cleanly in Excel"""
        TestReporter.init_excel()
        
        target_file = EXCEL_FILE if os.path.exists(EXCEL_FILE) else "execution_results_latest.xlsx"
        try:
            wb = load_workbook(target_file)
        except Exception:
            wb = load_workbook("execution_results_latest.xlsx")

        sheet_name = "Negative Tests" if sheet_type.upper() == "NEGATIVE" else "Positive Tests"
        ws = wb[sheet_name]
        
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        ws.append([timestamp, activity_name, input_data, status, error_or_result])
        
        try:
            wb.save(target_file)
        except PermissionError:
            wb.save("execution_results_latest.xlsx")

    @staticmethod
    def generate_pdf_report(report_logs):
        """Builds PDF Report with precise Red/Green status tags"""
        pdf_compiler = AutomationReport()
        pdf_compiler.build_pdf(report_logs)
        print("\n✅ [PDF GENERATED] Automation_Execution_Report.pdf created successfully.")