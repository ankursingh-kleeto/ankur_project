import os
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

class AutomationReport:
    def __init__(self, filename="Automation_Execution_Report.pdf"):
        self.filename = filename

    def build_pdf(self, report_logs):
        doc = SimpleDocTemplate(self.filename, pagesize=letter)
        styles = getSampleStyleSheet()
        story = []

        title_style = ParagraphStyle(
            'TitleStyle',
            parent=styles['Heading1'],
            fontSize=18,
            textColor=colors.HexColor('#003366'),
            spaceAfter=12
        )

        story.append(Paragraph("CNHI Onboarding Automation Execution Report", title_style))
        story.append(Spacer(1, 12))

        for log in report_logs:
            title = log.get("title", "Execution Step")
            status = log.get("status", "INFO")
            img_path = log.get("img_path", "")

            # Status color tag
            status_color = "#28a745" if status == "PASS" else "#dc3545"
            status_p = f"<b>Status:</b> <font color='{status_color}'>{status}</font>"

            table_data = [
                [Paragraph(f"<b>Test Case:</b> {title}", styles['Normal']), Paragraph(status_p, styles['Normal'])]
            ]

            t = Table(table_data, colWidths=[380, 120])
            t.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#f8f9fa')),
                ('BOX', (0, 0), (-1, -1), 1, colors.HexColor('#cccccc')),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('PADDING', (0, 0), (-1, -1), 6),
            ]))
            story.append(t)
            story.append(Spacer(1, 6))

            if img_path and os.path.exists(img_path):
                try:
                    img = Image(img_path, width=450, height=220)
                    story.append(img)
                except Exception as e:
                    story.append(Paragraph(f"<i>[Image embed error: {e}]</i>", styles['Italic']))
            
            story.append(Spacer(1, 15))

        doc.build(story)