from action_parser import parse_actions

def execute(page, ai_answer):

    actions = parse_actions(ai_answer)

    for action in actions:

        if action["action"]=="fill":

            page.fill(
                action["locator"],
                action["value"]
            )

        elif action["action"]=="click":

            page.click(
                action["locator"]
            )

        elif action["action"]=="upload":

            page.set_input_files(
                action["locator"],
                action["file"]
            )