import json
import re


class ActionParser:

    @staticmethod
    def parse(ai_response: str):
        """
        Convert AI response into Python list.

        Supports:
        1. Raw JSON
        2. JSON inside ```json ```
        """

        if not ai_response:
            raise ValueError("AI response is empty.")

        ai_response = ai_response.strip()

        # Remove Markdown code block if present
        match = re.search(r"```(?:json)?\s*(.*?)```", ai_response, re.DOTALL)

        if match:
            ai_response = match.group(1)

        try:
            actions = json.loads(ai_response)

        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON from AI.\n{e}")

        if not isinstance(actions, list):
            raise ValueError("AI output must be a list.")

        return actions

    @staticmethod
    def validate(actions):

        allowed_actions = [
            "fill",
            "click",
            "select",
            "upload",
            "check",
            "uncheck",
            "wait",
            "press",
            "goto",
            "assert_text",
            "assert_url",
            "screenshot"
        ]

        for index, action in enumerate(actions):

            if "action" not in action:
                raise ValueError(
                    f"Action #{index+1} missing 'action' key."
                )

            if action["action"] not in allowed_actions:
                raise ValueError(
                    f"Unsupported action : {action['action']}"
                )

        return True