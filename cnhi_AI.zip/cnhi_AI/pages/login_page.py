from playwright.sync_api import Page, expect

class LoginPage:
    url = "http://10.0.0.160/loginnew.php"

    def __init__(self, page: Page):
        self.page = page
        self.username_input = page.locator('#username, input[name="username"]')
        self.password_input = page.locator('input[name="password"]')
        self.captcha_container = page.locator('#captcha')
        self.captcha_input = page.locator('#captcha-form')
        self.login_button = page.locator('#submit_form')
        
        # Error text locators
        self.login_id_required_msg = page.get_by_text("Login ID field is required.")
        self.password_required_msg = page.get_by_text("Password field is required.")
        self.captcha_required_msg = page.get_by_text("Captcha field is required.")

    def open(self):
        print(f"[INFO] Navigating to: {self.url}")
        self.page.goto(self.url)

    def safe_fill(self, locator, value: str):
        """Readonly input fields ko bypass karke value fill karta hai"""
        if value:
            # Agar input readonly ho toh JavaScript se value inject karein
            locator.evaluate(f"(el, val) => {{ el.removeAttribute('readonly'); el.value = val; el.dispatchEvent(new Event('input', {{ bubbles: true }})); }}", value)

    def login_invalid(self, username="", password="", captcha=""):
        if username:
            self.safe_fill(self.username_input, username)
        if password:
            self.safe_fill(self.password_input, password)
        if captcha:
            self.safe_fill(self.captcha_input, captcha)
            
        self.login_button.click()