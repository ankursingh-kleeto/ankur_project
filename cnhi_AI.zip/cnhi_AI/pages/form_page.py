import os
import time
from playwright.sync_api import Page

class FormPage:
    def __init__(self, page: Page):
        self.page = page
        self.scratch_dir = "screenshots"
        os.makedirs(self.scratch_dir, exist_ok=True)
        self.form_payload_logs = []

    def process_form_by_token(self, form_token, index):
        try:
            print(f"\n[FORM PROCESS] Opening form card: '{form_token}'...")
            
            # Form link open trigger
            card_link = self.page.locator(f"//span[@title='{form_token}']/ancestor::div[contains(@class, 'card-body')]/following-sibling::div[contains(@class, 'card-footer')]//a").first
            if card_link.is_visible():
                card_link.click(force=True)
            else:
                self.page.locator("a:has-text('Fill Form'), a:has-text('Open')").first.click(force=True)
            
            time.sleep(3)
            form_safe_name = form_token.lower().replace(" ", "_")
            open_snap_path = os.path.join(self.scratch_dir, f"04_form_{index}_{form_safe_name}_opened.png")
            self.page.screenshot(path=open_snap_path)

            # Execution Engine
            self.handle_dropdowns()
            self.handle_inputs()
            self.handle_checkboxes()
            time.sleep(2)

            has_error = self.check_for_page_errors()
            submit_success = self.submit_form(form_token)

            save_snap_path = os.path.join(self.scratch_dir, f"04_form_{index}_{form_safe_name}_saved.png")
            self.page.screenshot(path=save_snap_path)

            if has_error:
                print(f"❌ [VALIDATION CHECK] Form '{form_token}' contains UI errors.")
                return False, open_snap_path, save_snap_path

            return submit_success, open_snap_path, save_snap_path

        except Exception as e:
            print(f"⚠️ Exception on processing form token '{form_token}': {e}")
            return False, None, None

    def handle_dropdowns(self):
        dropdowns = self.page.locator("select").all()
        for dropdown in dropdowns:
            try:
                if dropdown.is_visible() and dropdown.is_enabled():
                    f_label = str(dropdown.get_attribute("f_label") or "").lower()
                    data_tn = str(dropdown.get_attribute("data-tn") or "").lower()

                    # Row 2 & 3 Member exclusion matrix
                    if "member2" in data_tn or "member3" in data_tn or "member2" in f_label or "member3" in f_label:
                        continue

                    # Select option selection logic
                    options = dropdown.locator("option").all()
                    if len(options) > 1:
                        opt_value = options[1].get_attribute("value")
                        dropdown.select_option(value=opt_value if opt_value else options[1].inner_text().strip())
                        
                        log_msg = f"Dropdown [{f_label or data_tn}] Selected Option: {options[1].inner_text().strip()}"
                        print(f"   📝 {log_msg}")
                        self.form_payload_logs.append(log_msg)
            except Exception:
                pass

    def handle_inputs(self):
        text_inputs = self.page.locator("input[type='text'], input:not([type]), textarea").all()
        for field in text_inputs:
            try:
                if field.is_visible() and field.is_enabled() and not field.get_attribute("readonly") and not field.get_attribute("disabled"):
                    f_label = str(field.get_attribute("f_label") or "").lower()
                    data_tn = str(field.get_attribute("data-tn") or "").lower()
                    classes = str(field.get_attribute("class") or "").lower()
                    v_len = str(field.get_attribute("data-validation-length") or "")

                    # Deactivate Member 2 & 3 Fields
                    if "member2" in data_tn or "member3" in data_tn or "member2" in f_label or "member3" in f_label:
                        field.fill("")
                        continue

                    field.scroll_into_view_if_needed()

                    # Dynamic payload matching
                    payload_data = "TestEntryDetails"
                    if "datepicker" in classes or "date" in f_label or "dob" in f_label or "expiry" in f_label:
                        payload_data = "16-Jun-2026"
                    elif "age" in f_label:
                        payload_data = "32"
                    elif "passport" in f_label or "passport" in classes:
                        payload_data = "A1234567"
                    elif "aadhar" in f_label or "adhar" in classes or "12-12" in v_len:
                        payload_data = "123455643222"
                    elif "pan" in f_label or "pan" in classes:
                        payload_data = "ABCDE1234F"
                    elif "pincode" in f_label or "pin" in f_label:
                        payload_data = "110001"
                    elif "total_percen" in classes or "proportion" in f_label or "shared" in f_label:
                        payload_data = "100"
                    elif "mobile" in f_label or "phone" in f_label or "10-10" in v_len:
                        payload_data = "9876543210"
                    elif "email" in f_label:
                        payload_data = "testuser@mail.com"
                    elif "place" in f_label or "city" in f_label:
                        payload_data = "Delhi"
                    elif "house" in f_label or "village" in f_label or "address" in f_label:
                        payload_data = "Flat 101, Test Tower"
                    else:
                        current_val = field.input_value()
                        if current_val and current_val.strip() != "":
                            payload_data = current_val

                    field.fill(payload_data)

                    # Redaction Rule Applied
                    masked_log_val = "[Aadhaar Redacted]" if ("aadhar" in f_label or "adhar" in classes or "12-12" in v_len) else payload_data
                    
                    report_entry = f"Field Key: '{f_label or data_tn}' -> Value: '{masked_log_val}'"
                    print(f"   📝 [LOGGED] {report_entry}")
                    self.form_payload_logs.append(report_entry)
            except Exception:
                pass

    def handle_checkboxes(self):
        checkboxes = self.page.locator("input[type='checkbox']").all()
        for chk in checkboxes:
            try:
                if chk.is_visible() and not chk.is_checked():
                    chk.check(force=True)
                    print("   -> Checked declaration / address sync checkbox.")
            except Exception:
                pass

    def check_for_page_errors(self):
        try:
            errors = self.page.locator(".toast-error, .alert-danger, [style*='color: red']").all_inner_texts()
            visible_errors = [e.strip() for e in errors if e.strip() and "mandatory" not in e.lower()]
            if visible_errors:
                print(f"   ⚠️ [ALERT DETECTED]: {' | '.join(visible_errors)}")
                return True
            return False
        except Exception:
            return False

    def submit_form(self, form_token):
        try:
            save_btn = self.page.locator("button#efffgg_generic_new_new, button:has-text('Save Form')").first
            if save_btn.is_visible():
                save_btn.scroll_into_view_if_needed()
                save_btn.click(force=True)
                print(f"   🔥 [SUBMIT] Clicked 'Save Form' button for '{form_token}'.")
                time.sleep(3)
                return True
            return False
        except Exception as e:
            print(f"   ⚠️ Submit Error: {e}")
            return False