import os
import time
from playwright.sync_api import Page

class DocumentPage:
    def __init__(self, page: Page):
        self.page = page
        
        self.start_click_here = page.locator("a#candidate-next-upload-document, a:has-text('click here')").first
        self.file_input = page.locator("input[type='file']").first
        self.joint_select = page.locator("select#select-joint-doc-name").first
        self.next_button = page.locator("button.use_next, button:has-text('Next')").first
        self.card_body = page.locator("#contain-upload-file").first

    def trigger_wizard(self):
        """Wizard ko safely start karta hai"""
        print("[INFO] Triggering wizard layout via 'Click here' element...")
        try:
            if self.start_click_here.count() > 0 and self.start_click_here.is_visible():
                self.start_click_here.click()
                time.sleep(2)
        except Exception as e:
            print(f"-> [INFO] 'Click here' link trigger bypassed: {e}")

    def trigger_next_navigation(self, slot_index):
        """Next transition button click"""
        try:
            if self.next_button.count() > 0:
                self.next_button.scroll_into_view_if_needed()
                self.next_button.click(force=True)
                print(f"-> [NEXT] Clicked step transition button on slot {slot_index}.")
        except Exception as e:
            print(f"-> [WARNING] Next transition issue on slot {slot_index}: {e}")

    def capture_ui_error(self):
        """Screen se Malicious File Error Text Extract Karta hai"""
        error_msg = "Validation Triggered: File Error / Upload Blocked"
        try:
            time.sleep(2)
            # Dynamic extraction for 'Error: Error - Malicious File Found'
            malicious_el = self.page.locator("text=Malicious File Found, text=Malicious, .toast-error, .alert-danger, [style*='color: red']").first
            if malicious_el.count() > 0 and malicious_el.is_visible():
                error_msg = malicious_el.inner_text().strip()
        except Exception:
            pass
        return error_msg

    # =========================================================================
    # --- SCENARIO 1 & 2: NEGATIVE ATTEMPTS (BLANK & MALICIOUS test2.pdf) ---
    # =========================================================================
    def test_negative_upload(self, file_path=None):
        """Handles Blank Upload & Malicious File Upload (test2.pdf)"""
        self.trigger_wizard()
        time.sleep(1.5)

        if file_path and os.path.exists(file_path):
            print(f"🔒 [DOC NEGATIVE] Uploading Malicious File: {file_path}")
            if self.file_input.count() > 0:
                self.file_input.set_input_files(file_path)
                time.sleep(4)  # Malware scan response delay
        else:
            print("🔒 [DOC NEGATIVE] Testing Blank File Submission (Direct Next Click)...")
            self.trigger_next_navigation(slot_index=1)
            time.sleep(2)

        captured_err = self.capture_ui_error()
        print(f"🚨 Captured UI Message: '{captured_err}'")
        return captured_err

    # =========================================================================
    # --- SCENARIO 3: POSITIVE ATTEMPT (VALID test.pdf) ---
    # =========================================================================
    def upload_all_required_documents(self, file_path=r"D:\selinum\test.pdf", reporter=None):
        """Valid test.pdf Upload Pipeline"""
        print("\n🔓 [DOC POSITIVE] Starting Valid test.pdf Upload Pipeline...")

        self.trigger_wizard()

        total_documents = 11
        for i in range(1, total_documents + 1):
            print(f"\n[WIZARD STEP {i}/{total_documents}] Processing active document card panel...")
            time.sleep(2)

            # Skip pre-uploaded files
            try:
                card_body_text = self.card_body.inner_text() if self.card_body.count() > 0 else ""
                if "Uploaded" in card_body_text and "successfully" in card_body_text.lower():
                    print(f"-> [SKIP DETECTED] Document slot {i} already uploaded.")
                    if reporter:
                        reporter.log_to_excel("POSITIVE", f"Document Slot {i}", "Status: Pre-Uploaded", "PASS", "Document already verified (Skipped)")
                    if i == total_documents:
                        break
                    self.trigger_next_navigation(i)
                    continue
            except Exception as e:
                print(f"-> [INFO] Skip state inspection bypassed: {e}")

            # Dropdown Check
            try:
                joint_select = self.page.locator("select#select-joint-doc-name").first
                if joint_select.count() > 0 and joint_select.is_visible():
                    options = joint_select.locator("option").all()
                    if len(options) > 1:
                        joint_select.select_option(index=1)
                        time.sleep(1)
            except Exception as e:
                print(f"-> [WARNING] Dropdown bypassed: {e}")

            # Fresh Valid Attach
            try:
                if self.file_input.count() > 0 and os.path.exists(file_path):
                    self.file_input.set_input_files(file_path)
                    print(f"-> [UPLOAD] Valid File 'test.pdf' attached successfully in slot {i}.")
                    time.sleep(3)
                    if reporter:
                        reporter.log_to_excel("POSITIVE", f"Document Slot {i}", f"Attached: {file_path}", "PASS", "Valid Document Uploaded Successfully")
            except Exception as e:
                print(f"-> [FAIL] Upload failed on slot {i}: {e}")

            if i == total_documents:
                break

            self.trigger_next_navigation(i)

        return True

    def go_to_next_phase(self):
        print("[SUCCESS] Document stage completed.")
        time.sleep(2)