import os
import time
import pytest
from playwright.sync_api import Page
from pages.document_page import DocumentPage
from pages.form_page import FormPage
from utils.excel_pdf_reporter import TestReporter

def scrape_ui_errors(page: Page):
    """Page se Red Validation Text Capture karta hai"""
    possible_labels = [
        "Login ID field is required.", 
        "Password field is required.", 
        "Captcha field is required.", 
        "Incorrect CAPTCHA. Please try again.",
        "Invalid Credentials"
    ]
    captured = [lbl for lbl in possible_labels if page.get_by_text(lbl).is_visible()]
    
    if not captured:
        elements = page.locator(".toast-error, .alert-danger, font[color='red'], .text-danger").all_inner_texts()
        captured = [e.strip() for e in elements if e.strip()]
        
    return " | ".join(captured) if captured else "Validation Error Triggered (Access Denied)"

def test_dual_login_and_onboarding_workflow(page: Page):
    # RedHat Server Production URLs
    dashboard_base_url = "http://10.0.0.160/npjms-v2/"
    login_url = "http://10.0.0.160/loginnew.php"
    
    scratch_dir = "screenshots"
    os.makedirs(scratch_dir, exist_ok=True)
    report_logs = []

    # =========================================================================
    # --- STEP 1: LOGIN NEGATIVE SCENARIOS (BLANK & INVALID CREDENTIALS) ---
    # =========================================================================
    print("\n=======================================================")
    print("🔒 [STEP 1: LOGIN NEGATIVE TESTING STAGE]")
    print("=======================================================")
    
    page.goto(login_url)
    page.wait_for_load_state("networkidle")

    # 1.1 Blank Submit Attempt
    page.click("#submit_form")
    time.sleep(1.5)
    
    snap_blank = os.path.join(scratch_dir, "01_blank_login_error.png")
    page.screenshot(path=snap_blank)
    
    blank_err_text = scrape_ui_errors(page)
    input_blank = "Login ID: [EMPTY], Password: [EMPTY], Captcha: [EMPTY]"
    
    TestReporter.log_to_excel("NEGATIVE", "Login Attempt: Blank Fields", input_blank, "FAIL (REJECTED)", blank_err_text)
    report_logs.append({"title": "Activity: Blank Login Attempt - Access Denied", "status": "FAIL (REJECTED)", "img_path": snap_blank})

    # 1.2 Invalid Fake Credentials Attempt
    username_el = page.locator("#username")
    password_el = page.locator("#password")
    captcha_in = page.locator("#captcha-form")

    username_el.evaluate("el => { el.removeAttribute('readonly'); el.removeAttribute('disabled'); }")
    password_el.evaluate("el => { el.removeAttribute('readonly'); el.removeAttribute('disabled'); }")

    fake_user, fake_pass, fake_captcha = "fake_user@invalid.com", "WrongPassword123", "000000"
    username_el.fill(fake_user)
    password_el.fill(fake_pass)
    captcha_in.fill(fake_captcha)

    page.click("#submit_form")
    time.sleep(2)

    snap_fake = os.path.join(scratch_dir, "02_fake_credentials_error.png")
    page.screenshot(path=snap_fake)

    fake_err_text = scrape_ui_errors(page)
    input_fake = f"Login ID: {fake_user}, Password: {fake_pass}, Captcha: {fake_captcha}"

    TestReporter.log_to_excel("NEGATIVE", "Login Attempt: Invalid Credentials", input_fake, "FAIL (REJECTED)", fake_err_text)
    report_logs.append({"title": "Activity: Invalid Credentials Attempt - Access Denied", "status": "FAIL (REJECTED)", "img_path": snap_fake})

    # =========================================================================
    # --- STEP 2: REAL / POSITIVE LOGIN (VALID AUTHORIZED ACCESS) ---
    # =========================================================================
    print("\n=======================================================")
    print("🔓 [STEP 2: REAL / POSITIVE LOGIN AUTHORIZED STAGE]")
    print("=======================================================")

    page.goto(login_url)
    page.wait_for_load_state("networkidle")

    username_el = page.locator("#username")
    password_el = page.locator("#password")
    
    username_el.evaluate("el => { el.removeAttribute('readonly'); el.removeAttribute('disabled'); }")
    password_el.evaluate("el => { el.removeAttribute('readonly'); el.removeAttribute('disabled'); }")

    valid_user, valid_pass = "ankur.singh@kleeto.in", "111111"
    username_el.fill(valid_user)
    password_el.fill(valid_pass)

    captcha_box = page.locator("#captcha")
    raw_captcha = captcha_box.inner_text()
    clean_captcha = "".join(raw_captcha.split())

    page.locator("#captcha-form").fill(clean_captcha)
    page.click("#submit_form")
    time.sleep(4)

    # Robust URL & Dashboard locator check for RedHat
    dash_loaded = "npjms-v2" in page.url or page.locator("a[href*='document']").count() > 0 or page.locator("#candidate-document-stage").count() > 0
    status_dash = "PASS" if dash_loaded else "FAIL"
    
    snap_dash = os.path.join(scratch_dir, "03_dashboard_session.png")
    page.screenshot(path=snap_dash)

    input_valid = f"Login ID: {valid_user}, Password: {valid_pass}, Captcha: {clean_captcha}"
    TestReporter.log_to_excel("POSITIVE", "Login Attempt: Valid User Access", input_valid, status_dash, "Session Authorized & Dashboard Loaded" if dash_loaded else "Login Failed")
    report_logs.append({"title": "Activity: Valid Credentials Login - Access Granted", "status": status_dash, "img_path": snap_dash})

    # =========================================================================
    # --- STEP 3: DOCUMENT UPLOAD TESTING (FIRST THING AFTER LOGIN) ---
    # =========================================================================
    if dash_loaded:
        print("\n=======================================================")
        print("📄 [STEP 3: EXECUTING DOCUMENT UPLOAD TESTING NOW]")
        print("=======================================================")
        
        page.goto(dashboard_base_url)
        page.wait_for_load_state("networkidle")
        time.sleep(2)
        
        # Click Document Stage Icon/Button safely
        doc_stage_btn = page.locator("#candidate-document-stage, a[href*='document']").first
        if doc_stage_btn.count() > 0:
            doc_stage_btn.click(force=True)
            time.sleep(3)

        document_stage = DocumentPage(page)

        # --- 3.1 DOCUMENT SCENARIO 1: BLANK UPLOAD ATTEMPT ---
        print("\n🔒 [DOC ATTEMPT 1] Testing Blank File Submit...")
        doc_err_blank = document_stage.test_negative_upload(file_path=None)
        snap_blank_doc = os.path.join(scratch_dir, "04_doc_blank_submit_error.png")
        page.screenshot(path=snap_blank_doc)

        TestReporter.log_to_excel(
            "NEGATIVE", 
            "Document Stage: Blank File Submit Attempt", 
            "File Attached: [NONE]", 
            "FAIL (REJECTED)", 
            doc_err_blank
        )
        report_logs.append({
            "title": "Activity: Blank Document Submit - Access Denied",
            "status": "FAIL (REJECTED)",
            "img_path": snap_blank_doc
        })

        # --- 3.2 DOCUMENT SCENARIO 2: MALICIOUS FILE UPLOAD (test2.pdf) ---
        print("\n🔒 [DOC ATTEMPT 2] Testing Malicious File Upload (test2.pdf)...")
        malicious_file_path = r"D:\selinum\test2.pdf"
        
        doc_err_malicious = document_stage.test_negative_upload(file_path=malicious_file_path)
        snap_malicious_doc = os.path.join(scratch_dir, "05_doc_malicious_file_error.png")
        page.screenshot(path=snap_malicious_doc)

        TestReporter.log_to_excel(
            "NEGATIVE", 
            "Document Stage: Malicious File Upload Attempt", 
            f"File Attached: test2.pdf ({malicious_file_path})", 
            "FAIL (REJECTED)", 
            doc_err_malicious
        )
        report_logs.append({
            "title": "Activity: Malicious File Upload (test2.pdf) - Security Rejection",
            "status": "FAIL (REJECTED)",
            "img_path": snap_malicious_doc
        })

        # --- 3.3 DOCUMENT SCENARIO 3: VALID CORRECT FILE UPLOAD (test.pdf) ---
        print("\n🔓 [DOC ATTEMPT 3] Testing Valid Document Upload (test.pdf)...")
        valid_file_path = r"D:\selinum\test.pdf"
        doc_pos_success = document_stage.upload_all_required_documents(file_path=valid_file_path, reporter=TestReporter)
        document_stage.go_to_next_phase()

        snap_valid_doc = os.path.join(scratch_dir, "06_doc_valid_upload_success.png")
        page.screenshot(path=snap_valid_doc)

        report_logs.append({
            "title": "Activity: Valid Correct Document Upload Pipeline Completed (test.pdf)",
            "status": "PASS" if doc_pos_success else "FAIL",
            "img_path": snap_valid_doc
        })

        # --- STEP 4: CANDIDATE FORMS PIPELINE ---
        print("\n=======================================================")
        print("📄 [STEP 4: CANDIDATE FORMS PIPELINE]")
        print("=======================================================")
        master_production_forms = ["Application Form"]
        for index, form_token in enumerate(master_production_forms, 1):
            try:
                page.goto(dashboard_base_url)
                page.click("#candidate-forms-stage")
                time.sleep(2)

                form_page = FormPage(page)
                success, path_opened, path_saved = form_page.process_form_by_token(form_token, index)

                f_status = "PASS" if success else "FAIL"
                TestReporter.log_to_excel("POSITIVE", f"Workflow: Candidate Form [{form_token}]", f"Form Name: {form_token}", f_status, "Form Saved Successfully" if success else "Form Saving Failed")
                report_logs.append({"title": f"Activity: Form Submission [{form_token}]", "status": f_status, "img_path": path_saved if path_saved else snap_dash})
            except Exception as e:
                TestReporter.log_to_excel("POSITIVE", f"Workflow: Candidate Form [{form_token}]", f"Form Name: {form_token}", "FAIL", f"Error: {str(e)[:100]}")
    else:
        print("\n⚠️ [ERROR] Login failed on RedHat server! Please check credentials.")

    # Compile PDF Report
    TestReporter.generate_pdf_report(report_logs)